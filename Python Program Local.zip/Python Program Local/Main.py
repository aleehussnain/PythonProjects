from tkinter import Button, Entry, Tk, StringVar, Label, INSERT, ACTIVE, DISABLED, Text
from tkinter import ttk
from tkinter import messagebox, filedialog
from tkinter.filedialog import asksaveasfile

root = Tk()
root.geometry('1000x700')
root.title("Course Selector")
map2 = {'CS101': [3, '', '', ''],
'CS155': [4, 'CS101', '', ''],
'CS245': [3, 'CS101', '', ''],
'CS265': [4, 'CS155', '', ''],
'CS288' :[4, 'CS245', '', ''],
'CS300' :[3, 'CS265', '', ''],
'CS345' :[3, 'CS245', '', ''],
'CS350' :[3, ['CS300', 'CS345'], '', ''],
'CS351' :[4, 'CS155', '', ''],
'CS380' :[3, ['CS288', 'CS351'], '', ''],
'CS390' :[3, 'CS300', '', ''],
'CS433' :[3, 'CS300', '', ''],
'CS440': [3, 'CS265', '', ''],
'CS445': [3, 'Senior Standing', '', ''],
'CS480': [3, 'CS351', '', ''],
'CS495': [1, 'CS445', '', ''],
'CS499': [3, 'CS445', '', ''],
'CS591': [3, [['CS300', 'CS380', 'CS480'], ['CS300', 'CS503'], ['CS500', 'CS503']], '', ''],
'CY201': [4, 'CS155', '', ''],
'IU315': [3, '', '', ''],
'MA139': [3, [['ACT24'], ['MA116'], ['MA137']], '', ''],
'MA223': [3, [['ACT24'], ['MA116']], '', ''],
'MA464': [3, [['MA223'], ['MA250'], ['MA338'], ['MA345'], ['MA443']], '', ''],
'CS3xx+': [6, '', '', ''],
'Science': [9, '', '', ''],
'Social and Behavioral Sciences': [6, '', '', ''],
'PS103':[3, '', '', ''],
'Written Communication': [3, '', '', ''],
'EN100': [3, '', '', ''],
'SP104': [3, '', '', ''],
'Natural Sciences': [7, '', '', ''],
'Humanities and Fine Arts':[6, '', '', ''],
'AR104': [3, '', '', ''],
'Additional Requirements':[2, '', '', ''],
'UI100': [3, '', '', ''],
'Senior Standing': [0, '', '', ''],
'ACT24': [0, '', '', '']
       }


map = {'CS101': [3, '', '', ''],
'CS155': [4, 'CS101', '', ''],
'CS245': [3, 'CS101', '', ''],
'CS265': [4, 'CS155', '', ''],
'CS288' :[4, 'CS245', '', ''],
'CS300' :[3, 'CS265', '', ''],
'CS345' :[3, 'CS245', '', ''],
'CS350' :[3, ['CS300', 'CS345'], '', ''],
'CS351' :[4, 'CS155', '', ''],
'CS380' :[3, ['CS288', 'CS351'], '', ''],
'CS390' :[3, 'CS300', '', ''],
'CS433' :[3, 'CS300', '', ''],
'CS440': [3, 'CS265', '', ''],
'CS445': [3, 'Senior Standing', '', ''],
'CS480': [3, 'CS351', '', ''],
'CS495': [1, 'CS445', '', ''],
'CS499': [3, 'CS445', '', ''],
'CS591': [3, [['CS300', 'CS380', 'CS480'], ['CS300', 'CS503'], ['CS500', 'CS503']], '', ''],
'CY201': [4, 'CS155', '', ''],
'IU315': [3, '', '', ''],
'MA139': [3, [['ACT24'], ['MA116'], ['MA137']], '', ''],
'MA223': [3, [['ACT24'], ['MA116']], '', ''],
'MA464': [3, [['MA223'], ['MA250'], ['MA338'], ['MA345'], ['MA443']], '', ''],
'CS3xx+': [6, '', '', ''],
'Science': [9, '', '', ''],
'Social and Behavioral Sciences': [6, '', '', ''],
'PS103':[3, '', '', ''],
'Written Communication': [3, '', '', ''],
'EN100': [3, '', '', ''],
'SP104': [3, '', '', ''],
'Natural Sciences': [7, '', '', ''],
'Humanities and Fine Arts':[6, '', '', ''],
'AR104': [3, '', '', ''],
'Additional Requirements':[2, '', '', ''],
'UI100': [3, '', '', ''],
'Senior Standing': [0, '', '', ''],
'ACT24': [0, '', '', '']
       }

def register():
    root2 = Tk()
    root2.geometry('800x500')
    listofAllCourses2 = []

    def update_root2():
        if (combobox_course_selector_a.get() == ''):
            messagebox.showerror('Error', 'Please select the course')
            return
        map2[combobox_course_selector_a.get()][2] = ""
        course_Details_a.config(state='normal')
        term_Details_a.config(state='normal')
        year_Details_a.config(state='normal')
        listofAllCourses2.clear()
        course_Details_a.delete('1.0', 'end')
        term_Details_a.delete('1.0', 'end')
        year_Details_a.delete('1.0', 'end')

        for c, y in map2.items():
            # print(c,y)

            if type(y[1]) is not list:
                if (y[2] != ""):
                    # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
                    course_Details_a.insert(INSERT, "{}\n".format(c))
                    val = y[2].split(" ")
                    term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                    year_Details_a.insert(INSERT, "{}\n".format(val[1]))

                listofAllCourses2.append("{}|{}|{}|{}|{}\n".format(c, str(y[0]), str(y[1]), str(y[2]), str(y[3])))
            else:
                val = ''
                val2 = ''
                check = False
                if type(y[1]) is list:
                    for a in y[1]:
                        if type(a) is list:
                            check = True
                            for b in a:
                                val = val + "," + b
                            val = val + " "

                        else:
                            val = val + "," + a
                    if not check:
                        val = val.replace(',', '', 1)
                        # val = val.replace(val[val.rindex(",")],"")
                        if y[2] != "":
                            # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) ))
                            course_Details_a.insert(INSERT, "{}\n".format(c))
                            val = y[2].split(" ")
                            term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                            year_Details_a.insert(INSERT, "{}\n".format(val[1]))

                        listofAllCourses2.append(
                            "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))
                    else:
                        for d in val.split(" "):
                            val3 = d.replace(',', '', 1)
                            val2 = " " + val3 + val2
                        val2 = val2.replace(" ", '', 1)
                        val2 = val2.replace(" ", '', 1)

                        # print(val2)
                        if y[2] != "":
                            # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) ))
                            course_Details_a.insert(INSERT, "{}\n".format(c))
                            val = y[2].split(" ")
                            term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                            year_Details_a.insert(INSERT, "{}\n".format(val[1]))

                        listofAllCourses2.append(
                            "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                        # hb = course_Details_a.get('1.0','end')
                        # for fg in hb.split('\n'):
                        #     print(fg)

        for h in listofAllCourses2:
            h = h.strip()

        combobox_term_selector_a.set('')
        combobox_course_selector_a.set('')
        course_Details_a.config(state='disabled')
        term_Details_a.config(state='disabled')
        year_Details_a.config(state='disabled')

    def addTermAndSession_root2():
        course_Details_a.config(state='normal')
        term_Details_a.config(state='normal')
        year_Details_a.config(state='normal')

        listofAllCourses2.clear()

        if (combobox_course_selector_a.get() == ''):
            messagebox.showerror('Error', 'Please select the course')
            return
        elif (combobox_term_selector_a.get() == ''):
            messagebox.showerror('Error', 'Please select the Term and Year')
            return
        elif (e11.get() == ''):
            messagebox.showerror('Error', 'Please Enter Student ID')
            return
        elif (e2.get() == ''):
            messagebox.showerror('Error', 'Please Enter Year')
            return

        valMac = 1
        for i in map2.values():
            if (str(combobox_term_selector_a.get()) == i[2]):
                print("True")
                if (valMac < 4):
                    print(valMac)
                    valMac = valMac + 1
                else:
                    messagebox.showerror('Error',
                                         'You have registered 4 course in {} cannot registere any more courses in it'.format(
                                             combobox_term_and_year_selector.get()))

        course_Details_a.delete('1.0', 'end')
        term_Details_a.delete('1.0', 'end')
        year_Details_a.delete('1.0', 'end')

        # varOfStr = ''
        # for i in e11.get():
        #     if( i != '' and i != '\n'):
        #         varOfStr = varOfStr + i
        #     else:
        #         print("true of end line")
        # print(varOfStr)
        if (str(e11.get()).isalnum() is False):
            messagebox.showerror('Error', 'Enter ID is not alphanumeric')


        map2[combobox_course_selector_a.get()][2] = '{} {}'.format(combobox_term_selector_a.get(), e2.get())
        for c, y in map2.items():
            # print(c,y)

            if type(y[1]) is not list:
                if (y[2] != ""):
                    # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}\n".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
                    course_Details_a.insert(INSERT, "{}\n".format(c))
                    val = y[2].split(" ")
                    term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                    year_Details_a.insert(INSERT, "{}\n".format(val[1]))

                listofAllCourses2.append("{}|{}|{}|{}|{}\n".format(c, str(y[0]), str(y[1]), str(y[2]), str(y[3])))
            else:
                val = ''
                val2 = ''
                check = False
                if type(y[1]) is list:
                    for a in y[1]:
                        if type(a) is list:
                            check = True
                            for b in a:
                                val = val + "," + b
                            val = val + " "

                        else:
                            val = val + "," + a
                    if not check:
                        val = val.replace(',', '', 1)
                        # val = val.replace(val[val.rindex(",")],"")
                        if y[2] != "":
                            # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))

                            course_Details_a.insert(INSERT, "{}\n".format(c))
                            val = y[2].split(" ")
                            term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                            year_Details_a.insert(INSERT, "{}\n".format(val[1]))
                            listofAllCourses2.append(
                                "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))
                    else:
                        for d in val.split(" "):
                            val3 = d.replace(',', '', 1)
                            val2 = " " + val3 + val2
                        val2 = val2.replace(" ", '', 1)
                        val2 = val2.replace(" ", '', 1)

                        # print(val2)
                        if y[2] != "":
                            # course_Details_a.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                            course_Details_a.insert(INSERT, "{}\n".format(c))
                            val = y[2].split(" ")
                            term_Details_a.insert(INSERT, "{}\n".format(val[0]))
                            year_Details_a.insert(INSERT, "{}\n".format(val[1]))

                        listofAllCourses2.append(
                            "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                        # hb = course_Details_a.get('1.0','end')
                        # for fg in hb.split('\n'):
                        #     print(fg)

        for h in listofAllCourses2:
            h = h.strip()

        combobox_term_selector_a.set('')
        combobox_course_selector_a.set('')
        course_Details_a.config(state='disabled')
        term_Details_a.config(state='disabled')
        year_Details_a.config(state='disabled')

    labelOfStudentID = Label(root2, text="Student ID:", bg='light green', font=('Verdana', 15))
    labelOfStudentID.place(x=25, y=25)
    e11 = Entry(root2)
    e11.place(x=25, y=55)

    labelyear = Label(root2, text=" Year:", bg='light green', font=('Verdana', 15))
    labelyear.place(x=25, y=230)
    e2 = Entry(root2)
    e2.place(x=25, y=260)

    label5_aa = Label(root2, text="Courses", bg='light green', font=('Verdana', 11))
    label5_aa.place(x=250, y=25)
    course_Details_a = Text(root2, height=16, width=23)
    course_Details_a.config(state='disabled')
    course_Details_a.place(x=250, y=55)

    label5_b_a = Label(root2, text="Term", bg='light green', font=('Verdana', 11))
    label5_b_a.place(x=450, y=25)
    term_Details_a = Text(root2, height=16, width=15)
    term_Details_a.config(state='disabled')
    term_Details_a.place(x=450, y=55)

    label5_c_a = Label(root2, text="Year", bg='light green', font=('Verdana', 11))
    label5_c_a.place(x=580, y=25)
    year_Details_a = Text(root2, height=16, width=15)
    year_Details_a.config(state='disabled')
    year_Details_a.place(x=580, y=55)

    label3_a = Label(root2, text="Select Term", bg='light green', font=('Verdana', 15))
    label3_a.place(x=25, y=100)
    combobox_term_selector_a = ttk.Combobox(root2, values=["Spring", "Fall"], )
    combobox_term_selector_a.place(x=25, y=130)

    label2_a = Label(root2, text='Select Course', bg='light green', font=('Verdana', 15))
    label2_a.place(x=25, y=160)
    combobox_course_selector_a = ttk.Combobox(root2, width=30)
    combobox_course_selector_a.place(x=25, y=200)
    listOfCourses2 = []
    for x, b in map2.items():
        if (b[2] == ''):
            listOfCourses2.append(x)
    combobox_course_selector_a['values'] = listOfCourses2
    # combobox_course_selector_a.bind("<<ComboboxSelected>>", lambda a: callbackFunc(combobox_course_selector_a.get()))

    registerButton_a = Button(root2, text="Register", command=addTermAndSession_root2, activebackground='#345',
                              activeforeground='white', width=10)
    registerButton_a.place(x=25, y=290)

    deleteButton = Button(root2, text="Delete", command=update_root2, activebackground='#345', activeforeground='white',
                          width=10)
    deleteButton.place(x=25, y=330)

    root2.configure(background="light green")
    root2.title("Course Selector")
    root2.mainloop()


lab6 = StringVar()
lab6.set("CGPA:")



def calculateGPA():
    count = 0
    number = 0
    credhours = 0
    for i in map.values():
        if(i[3] == "A" or i[3] == "A\n"):
            count = count + 1
            number = number + 4
            credhours = credhours + int(i[0])


        elif (i[3] == "B" or i[3] == "B\n"):
            count = count + 1
            number = number + 3
            credhours = credhours + int(i[0])


        elif (i[3] == "C" or i[3] == "C\n"):
            count = count + 1
            number = number + 2
            credhours = credhours + int(i[0])

        elif (i[3] == "D" or i[3] == "D\n"):
            count = count + 1
            number = number + 1
            credhours = credhours + int(i[0])

    return number/count

listofAllCourses = []

def update():
    course_Details.config(state='normal')
    term_Details.config(state='normal')
    year_Details.config(state='normal')
    listofAllCourses.clear()
    course_Details.delete('1.0', 'end')
    term_Details.delete('1.0', 'end')
    year_Details.delete('1.0', 'end')

    for c, y in map.items():
        #print(c,y)

        if type(y[1]) is not list:
            if(y[2] != ""):
                #course_Details.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
                course_Details.insert(INSERT, "{}\n".format(c))
                val = y[2].split(" ")
                term_Details.insert(INSERT, "{}\n".format(val[0]))
                year_Details.insert(INSERT, "{}\n".format(val[1]))

            listofAllCourses.append("{}|{}|{}|{}|{}\n".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
        else:
            val = ''
            val2 = ''
            check = False
            if type(y[1]) is list:
                for a in y[1]:
                    if type(a) is list:
                        check =True
                        for b in a:
                            val = val + "," + b
                        val = val + " "

                    else:
                        val = val + "," + a
                if not check:
                    val = val.replace(',','',1)
                    #val = val.replace(val[val.rindex(",")],"")
                    if y[2] != "":
                        #course_Details.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) ))
                        course_Details.insert(INSERT, "{}\n".format(c))
                        val = y[2].split(" ")
                        term_Details.insert(INSERT, "{}\n".format(val[0]))
                        year_Details.insert(INSERT, "{}\n".format(val[1]))

                    listofAllCourses.append("{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))
                else:
                    for d in val.split(" "):
                        val3 = d.replace(',', '', 1)
                        val2 = " " + val3 + val2
                    val2 = val2.replace(" ", '', 1)
                    val2 = val2.replace(" ", '', 1)

                    # print(val2)
                    if y[2] != "":
                        #course_Details.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) ))
                        course_Details.insert(INSERT, "{}\n".format(c))
                        val = y[2].split(" ")
                        term_Details.insert(INSERT, "{}\n".format(val[0]))
                        year_Details.insert(INSERT, "{}\n".format(val[1]))

                    listofAllCourses.append("{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                    # hb = course_Details.get('1.0','end')
                    # for fg in hb.split('\n'):
                    #     print(fg)
        root.update_idletasks()

    for h in listofAllCourses:
        h = h.strip()

    lab6.set("CGPA:{:.2f}".format(calculateGPA()))
    combobox_term_and_year_selector.set('')
    combobox_grades.set('')
    combobox_course_selector.set('')
    course_Details.config(state='disabled')
    term_Details.config(state='disabled')
    year_Details.config(state='disabled')



def addTermAndSession():
    course_Details.config(state='normal')
    term_Details.config(state='normal')
    year_Details.config(state='normal')

    listofAllCourses.clear()

    if(combobox_course_selector.get() == ''):
        messagebox.showerror('Error', 'Please select the course')
        return
    elif(combobox_term_and_year_selector.get() == ''):
        messagebox.showerror('Error', 'Please select the Term and Year')
        return
    elif(combobox_grades.get() == ''):
        messagebox.showerror('Error', 'Please Select the grades for course')
        return
    elif(e1.get() == ''):
        messagebox.showerror('Error', 'Please Enter Student ID')
        return


    valMac = 1
    for i in map.values():
        if(str(combobox_term_and_year_selector.get()) == i[2]):
            print("True")
            if(valMac<4):
                print(valMac)
                valMac = valMac + 1
            else:
                messagebox.showerror('Error', 'You have registered 4 course in {} cannot registere any more courses in it'.format(combobox_term_and_year_selector.get()))
                return
    course_Details.delete('1.0','end')
    term_Details.delete('1.0','end')
    year_Details.delete('1.0','end')

    # varOfStr = ''
    # for i in e1.get():
    #     if( i != '' and i != '\n'):
    #         varOfStr = varOfStr + i
    #     else:
    #         print("true of end line")
    # print(varOfStr)
    if(str(e1.get()).isalnum() is False):
        messagebox.showerror('Error', 'Enter ID is not alphanumeric')
        return

    map[combobox_course_selector.get()][2] = combobox_term_and_year_selector.get()
    map[combobox_course_selector.get()][3] = combobox_grades.get()
    for c, y in map.items():
        # print(c,y)

        if type(y[1]) is not list:
            if(y[2] != ""):
                #course_Details.insert(INSERT, "{}|{}|{}|{}|{}\n".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
                course_Details.insert(INSERT, "{}\n".format(c))
                val = y[2].split(" ")
                term_Details.insert(INSERT, "{}\n".format(val[0]))
                year_Details.insert(INSERT, "{}\n".format(val[1]))

            listofAllCourses.append("{}|{}|{}|{}|{}\n".format(c, str(y[0]),str(y[1]),str(y[2]),str(y[3]) ))
        else:
            val = ''
            val2 = ''
            check = False
            if type(y[1]) is list:
                for a in y[1]:
                    if type(a) is list:
                        check =True
                        for b in a:
                            val = val + "," + b
                        val = val + " "

                    else:
                        val = val + "," + a
                if not check:
                    val = val.replace(',','',1)
                    #val = val.replace(val[val.rindex(",")],"")
                    if y[2] != "":
                        #course_Details.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))

                        course_Details.insert(INSERT, "{}\n".format(c))
                        val = y[2].split(" ")
                        term_Details.insert(INSERT, "{}\n".format(val[0]))
                        year_Details.insert(INSERT, "{}\n".format(val[1]))
                        listofAllCourses.append("{}|{}|{}|{}|{}".format(c, str(y[0]), val, str(y[2]), str(y[3]) + "\n"))
                else:
                    for d in val.split(" "):
                        val3 = d.replace(',', '', 1)
                        val2 = " " + val3 + val2
                    val2 = val2.replace(" ", '', 1)
                    val2 = val2.replace(" ", '', 1)

                    # print(val2)
                    if y[2] != "":
                        #course_Details.insert(INSERT, "{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                        course_Details.insert(INSERT, "{}\n".format(c))
                        val = y[2].split(" ")
                        term_Details.insert(INSERT, "{}\n".format(val[0]))
                        year_Details.insert(INSERT, "{}\n".format(val[1]))

                    listofAllCourses.append("{}|{}|{}|{}|{}".format(c, str(y[0]), val2, str(y[2]), str(y[3]) + "\n"))
                    # hb = course_Details.get('1.0','end')
                    # for fg in hb.split('\n'):
                    #     print(fg)
        root.update_idletasks()

    for h in listofAllCourses:
        h = h.strip()

    lab6.set("CGPA:{:.2f}".format(calculateGPA()))
    setStartTermYear()
    combobox_term_and_year_selector.set('')
    combobox_grades.set('')
    combobox_course_selector.set('')
    Button_Save.configure(state=ACTIVE)
    course_Details.config(state='disabled')
    term_Details.config(state='disabled')
    year_Details.config(state='disabled')
    updateCourses()
def postRequisite(name,postval):
    for i in map.keys():
        if (type(map[name][1]) is not list):
            if i == map[name][1]:
                postval = postval + 1
                if map[i][1] != '':
                    postval = postRequisite(i, postval)
                    return postval
                else:
                    return postval
        else:
            for ax in map[name][1]:
                if type(ax) is list:
                    for bx in ax:
                        if bx == i:
                            postval = postval + 1
                            if map[i][1] != '':
                                postval = postRequisite(i, postval)
                                return postval
                            else:
                                return postval
                else:
                    if ax == i:
                        postval = postval + 1
                        if map[i][1] != '':
                            postval = postRequisite(i, postval)
                            return postval
                        else:
                            return postval
    return postval

def preRequisite(name, preval):
    for q, n in map.items():
        if(type(n[1]) is not list):
            if(n[1]==name):
                # print(name, q)
                preval = preval + 1
                ans = preRequisite(q, preval)
                return ans
        elif(type(n[1]) is list):
            for a in n[1]:
                if(type(a) is list):
                    for b in a:
                        if(b == name):
                            # print(name, q)
                            preval = preval + 1
                            ans = preRequisite(q, preval)
                            return ans
                else:
                    if a == name:
                        # print(name, q)
                        preval = preval +1
                        ans = preRequisite(q, preval)
                        return ans
    return preval



def generateTermsYears(name):
    listofTerms = ['Fall 2020', 'Spring 2021', 'Fall 2021', 'Spring 2022', 'Fall 2022', 'Spring 2023', 'Fall 2023', 'Spring 2024']
    listTodisplay = []
    listTodisplay.clear()
    if(map[name][1] == '' or map[name][1] == "Senior Standing" or map[name][1] == "ACT24"):
        for f in range(0,(8-preRequisite(name, 1))):
            listTodisplay.append(listofTerms[f])
        listTodisplay = list(dict.fromkeys(listTodisplay))
        combobox_term_and_year_selector['values'] = listTodisplay
    else:
        if type(map[name][1]) is not list:
           val = listofTerms.index(map[map[name][1]][2])
           listTodisplay.append(listofTerms[val+1])
        else:
            for ax in map[name][1]:
                if(type(ax) is list):
                    for bx in ax:
                        if( bx in map.keys()):
                            if(bx == "Senior Standing" or bx == "ACT24"):
                                for f in range(0, (8 - preRequisite(name, 1))):
                                    listTodisplay.append(listofTerms[f])
                                listTodisplay = list(dict.fromkeys(listTodisplay))
                                combobox_term_and_year_selector['values'] = listTodisplay
                                break
                            else:
                                val = listofTerms.index(map[bx][2])
                                listTodisplay.append(listofTerms[val + 1])
                        else:
                            break
                else:

                    val = listofTerms.index(map[ax][2])
                    listTodisplay.append(listofTerms[val+1])

        # print(val)
        # for f in range():
        #     listTodisplay.append(listofTerms[f])
        listTodisplay = list(dict.fromkeys(listTodisplay))
        combobox_term_and_year_selector['values'] = listTodisplay




def callbackFunc(name):
    combobox_term_and_year_selector.set('')
    global check
    if(map[name][2]!= '' and (map[name][3]!= '' or map[name][3]!= '\n')):
        messagebox.showerror('Error', 'The course is already completed')
        combobox_course_selector.set('')
        return
    if(map[name][1] != '' and name != 'ACT24' and name != 'Senior Standing'):
        if(type(map[name][1]) is list):
            count1 = 0
            for b in map[name][1]:
                if(type(b) is list):
                    count2 = 0
                    for x_a in b:
                        if(x_a == 'ACT24' or x_a == 'Senior Standing'):
                            check = True
                            generateTermsYears(name)
                            return True
                        else:
                            if(x_a in map.keys()):
                                if(map[x_a][3] == '' or map[x_a][3] == '\n'):
                                    break
                                else:
                                    count2 = count2 + 1
                                    #print(len(b),count2)
                                    if(len(b)==count2):
                                        check = True
                                        generateTermsYears(name)
                                        return True
                else:
                    if b in map.keys():
                        if (map[b][3] == '' or map[b][3] == '\n'):
                            break
                        else:
                            #print(b,type(map[b][3]))
                            count1 = count1 + 1
                            #print(count1,len(map[name][1]))
                            if (len(map[name][1]) == count1):

                                generateTermsYears(name)
                                check = True
                                return True
                    else:
                        messagebox.showerror('Error', 'This course '+ b + ' is not offered to you')
                        combobox_course_selector.set('')
            messagebox.showerror('Error','The prerequisite for this course is not done yet!')
            combobox_course_selector.set('')
            check = False
            return False
        else:
            if(map[name][1]  == 'ACT24' or map[name][1]  == 'Senior Standing'):
                generateTermsYears(name)
                check = True
                return True
            else:
                if(map[map[name][1]][3] == '' or map[map[name][1]][3] == '\n'):
                    messagebox.showerror('Error', 'The prerequisite for this course is not done yet!')
                    combobox_course_selector.set('')
                    check = False
                    return False
                else:


                    generateTermsYears(name)
                    check = True
                    return True
    else:
        if(name == "ACT24" or name == "Senior Standing"):
            messagebox.showerror('Error', 'Selected Value is '+name+' which is not a course')
            combobox_course_selector.set('')
        else:
            generateTermsYears(name)
            check = 'No Prereq'
            return 'No Prereq'

def save():
    f = asksaveasfile(initialfile='{}.txt'.format(str(e1.get())),
                      defaultextension=".txt", filetypes=[("All Files", "*.*"), ("Text Documents", "*.txt")])

    a = open(f.name, "a")
    # content = course_Details.get('1.0', 'end')
    # content = content.strip()
    # for i in content.split("\n"):
    #     r = i.strip()
    #     a.write(i+"\n")

    for i in listofAllCourses:

        r = i.strip()
        a.write(r+"\n")
    a.close()
    messagebox.showinfo('Information', 'File is saved')

    Button_Save.configure(state=DISABLED)

def file_chooser():

    e1.delete(0,'end')
    val = ""
    filename = filedialog.askopenfilenames(title='select', filetypes=[("All Files", "*.*"), ("Text Documents", "*.txt")])

    for r in filename:

        val = r
    f = open(val, 'r')
    cv = f.name.split("/")[len(f.name.split("/"))-1]
    e1.insert(0, cv.split(".")[0])
    for g in f:
        if not g.isspace():
            lst = g.split("|")
            # print(len(lst))
            if lst[2] == '':
                map[lst[0]] = [lst[1], lst[2], lst[3], lst[4]]
            elif lst[2] != '':
                if("," not in lst[2] and " " not in lst[2]):
                    map[lst[0]] = [lst[1], lst[2], lst[3], lst[4]]
                elif "," in lst[2] and " " not in lst[2]:
                    map[lst[0]] = [lst[1], lst[2].split(","), lst[3], lst[4]]
                elif "," in lst[2] and " " in lst[2]:
                    lst1 = []
                    for brk in lst[2].split(" "):
                        lst1.append(brk.split(","))
                    map[lst[0]] = [lst[1], lst1, lst[3], lst[4]]
                elif "," not in lst[2] and " " in lst[2]:
                    lst2 = []
                    for brk in lst[2].split(" "):
                        lst2.append([brk])
                    map[lst[0]] = [lst[1], lst2, lst[3], lst[4]]
    update()
    updateCourses()
    # for j, m in map.items():
       # print(j, m)
combobox_course_selector = ttk.Combobox(root,width= 30)
combobox_course_selector.place(x=25, y=415)
listOfCourses = []
for x in map.keys():
    listOfCourses.append(x)
combobox_course_selector['values'] = listOfCourses
combobox_course_selector.bind("<<ComboboxSelected>>", lambda a: callbackFunc(combobox_course_selector.get()))

label1 = Label(root, text = 'Auto advising form',bg= 'light green',font =('Verdana', 32))
label1.place(x = 300,y=5)

label2 = Label(root, text = 'Select Course',bg= 'light green',font =('Verdana', 15))
label2.place(x = 25,y=375)

label3 = Label(root, text="Select Term and Year", bg='light green', font=('Verdana', 15))
label3.place(x=25, y=455)

combobox_term_and_year_selector = ttk.Combobox(root, values=["1", "2", "3", "4", "5"],)
combobox_term_and_year_selector.place(x=25, y=495)


label4 = Label(root, text = "Grades",bg= 'light green',font =('Verdana', 15))
label4.place(x = 25,y=535)
combobox_grades = ttk.Combobox(root,values=["A", "B", "C", "D", "F"])
combobox_grades.place(x=25,y=575)


labelID = Label(root, text = "Student ID:",bg= 'light green',font =('Verdana', 15))
labelID.place(x = 25,y=615)
e1 = Entry(root)
e1.place(x =25, y = 655)
# text_box = Text(root,height=1,width=20)
# text_box.place(x =400, y = 115)


addButton = Button(root,text="Add",command = addTermAndSession,activebackground='#345',activeforeground='white', width = 10)
addButton.place(x=320,y=575)

registerButton = Button(root,text="Register",command = register ,activebackground='#345',activeforeground='white', width = 10)
registerButton.place(x=320,y=625)

Button_File_Chooser = Button(root,text = "Open File", command =file_chooser,width= 10)
Button_File_Chooser.place(x =25, y = 75)

Button_Save = Button(root,text = "Save",command=save ,width= 10 )
Button_Save.place(x =220, y = 575)
Button_Save.configure(state=DISABLED)
term = StringVar()
year = StringVar()
term.set("            ")
year.set("            ")

def setStartTermYear():
    term.set(str(combobox_term_and_year_selector.get().split(" ")[0]))
    year.set(str(combobox_term_and_year_selector.get().split(" ")[1]))

label5_start_term_year = Label(root, text = "Start term and year",bg= 'light green',font =('Verdana', 13))
label5_start_term_year.place(x = 25,y=150)

label5_t = Label(root, text = "Term:",bg= 'light green',font =('Verdana', 11))
label5_t.place(x = 25,y=180)

label5_y = Label(root, text = "Year:",bg= 'light green',font =('Verdana', 11))
label5_y.place(x = 25,y=210)

label5_term = Label(root, textvariable = term,font =('Verdana', 11))
label5_term.place(x = 80,y=180)

label5_year = Label(root, textvariable = year,font =('Verdana', 11))
label5_year.place(x = 80,y=210)


label5 = Label(root, text = "Semester Planning",bg= 'light green',font =('Verdana', 25))
label5.place(x = 290,y=345)

label6 = Label(root, textvariable=lab6 ,bg= 'light green',font =('Verdana', 15))
label6.place(x = 810,y=355)

label5_a = Label(root, text = "Courses",bg= 'light green',font =('Verdana', 11))
label5_a.place(x = 415,y=390)
course_Details = Text(root,height=16, width=23 )
course_Details.config(state='disabled')
course_Details.place(x=415,y=410)

label5_b = Label(root, text = "Term",bg= 'light green',font =('Verdana', 11))
label5_b.place(x = 615,y=390)
term_Details = Text(root,height=16, width=15 )
term_Details.config(state='disabled')
term_Details.place(x=615,y=410)

label5_c = Label(root, text = "Year",bg= 'light green',font =('Verdana', 11))
label5_c.place(x = 815,y=390)
year_Details = Text(root,height=16, width=15 )
year_Details.config(state='disabled')
year_Details.place(x=815,y=410)


label4 = Label(root, text = "Courses",bg= 'light green',font =('Verdana', 15))
label4.place(x = 200,y=55)
course_Names = Text(root,height=15, width=30 )
course_Names.config(state='disabled')
course_Names.place(x=200,y=95)

label4 = Label(root, text = "Credit Hours",bg= 'light green',font =('Verdana', 15))
label4.place(x = 470,y=55)
course_credit_hours = Text(root,height=15, width=10 )
course_credit_hours.config(state='disabled')
course_credit_hours.place(x=470,y=95)

label4 = Label(root, text = "Prerequisite",bg= 'light green',font =('Verdana', 15))
label4.place(x = 620,y=55)
course_prerequisites = Text(root,height=15, width=30 )
course_prerequisites.config(state='disabled')
course_prerequisites.place(x=620,y=95)

label4 = Label(root, text = "Grades",bg= 'light green',font =('Verdana', 15))
label4.place(x = 880,y=55)
course_grades = Text(root,height=15, width=10 )
course_grades.config(state='disabled')
course_grades.place(x=880,y=95)
def updateCourses():

    course_Names.config(state='normal')
    course_credit_hours.config(state='normal')
    course_prerequisites.config(state='normal')
    course_grades.config(state='normal')

    course_Names.delete('1.0','end')
    course_credit_hours.delete('1.0','end')
    course_prerequisites.delete('1.0','end')
    course_grades.delete('1.0','end')

    count = 0
    for x, y in map.items():
        count = count + 1
        course_Names.insert(INSERT,"{}. {}\n".format(count,x))
        course_credit_hours.insert(INSERT,"{}. {}\n".format(count,y[0]))
        if(type(y[1]) is not list ):
            course_prerequisites.insert(INSERT, "{}. {}\n".format(count, y[1]))
        else:
            course_prerequisites.insert(INSERT, "{}. {}\n".format(count, y[1]))
        if(y[3].endswith("\n")):
            course_grades.insert(INSERT,"{}. {}".format(count,y[3]))
        else:
            course_grades.insert(INSERT,"{}. {}\n".format(count,y[3]))
    course_Names.config(state='disable')
    course_credit_hours.config(state='disable')
    course_prerequisites.config(state='disable')
    course_grades.config(state='disable')



root.configure(background="light green")
root.mainloop()